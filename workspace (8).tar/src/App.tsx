import { useState, useEffect, useCallback, useRef } from 'react';
import { Play, Pause, RotateCcw, Settings, BarChart3, CheckCircle2, Clock, Timer, Coffee, Sun } from 'lucide-react';

// Types
type TimerMode = 'focus' | 'shortBreak' | 'longBreak';

interface TimerSettings {
  focus: number;
  shortBreak: number;
  longBreak: number;
}

interface FocusSession {
  date: string;
  duration: number;
  completedAt: string;
}

interface Stats {
  sessions: FocusSession[];
}

// Constants
const DEFAULT_SETTINGS: TimerSettings = {
  focus: 25,
  shortBreak: 5,
  longBreak: 15,
};

const MODE_CONFIG = {
  focus: {
    label: 'Фокусировка',
    icon: Timer,
    bgClass: 'bg-red-50',
    textClass: 'text-red-600',
    ringClass: 'stroke-red-500',
    btnClass: 'bg-red-500 hover:bg-red-600',
    borderClass: 'border-red-200',
    gradientClass: 'from-red-500 to-orange-500',
  },
  shortBreak: {
    label: 'Короткий перерыв',
    icon: Coffee,
    bgClass: 'bg-green-50',
    textClass: 'text-green-600',
    ringClass: 'stroke-green-500',
    btnClass: 'bg-green-500 hover:bg-green-600',
    borderClass: 'border-green-200',
    gradientClass: 'from-green-500 to-emerald-500',
  },
  longBreak: {
    label: 'Длинный перерыв',
    icon: Sun,
    bgClass: 'bg-blue-50',
    textClass: 'text-blue-600',
    ringClass: 'stroke-blue-500',
    btnClass: 'bg-blue-500 hover:bg-blue-600',
    borderClass: 'border-blue-200',
    gradientClass: 'from-blue-500 to-indigo-500',
  },
};

// Utility functions
function getToday(): string {
  return new Date().toISOString().split('T')[0];
}

function loadSettings(): TimerSettings {
  try {
    const saved = localStorage.getItem('pomodoro-settings');
    if (saved) return JSON.parse(saved);
  } catch (e) {
    console.error('Error loading settings:', e);
  }
  return DEFAULT_SETTINGS;
}

function saveSettings(settings: TimerSettings): void {
  localStorage.setItem('pomodoro-settings', JSON.stringify(settings));
}

function loadStats(): Stats {
  try {
    const saved = localStorage.getItem('pomodoro-stats');
    if (saved) return JSON.parse(saved);
  } catch (e) {
    console.error('Error loading stats:', e);
  }
  return { sessions: [] };
}

function saveStats(stats: Stats): void {
  localStorage.setItem('pomodoro-stats', JSON.stringify(stats));
}

function formatTime(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}

function getTodaySessions(stats: Stats): FocusSession[] {
  const today = getToday();
  return stats.sessions.filter(s => s.date === today);
}

function getTotalFocusMinutes(stats: Stats): number {
  const todaySessions = getTodaySessions(stats);
  return todaySessions.reduce((sum, s) => sum + s.duration, 0);
}

function getTodaySessionCount(stats: Stats): number {
  return getTodaySessions(stats).length;
}

// Components
function CircularProgress({ progress, mode, isRunning }: { progress: number; mode: TimerMode; isRunning: boolean }) {
  const config = MODE_CONFIG[mode];
  const radius = 120;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (progress / 100) * circumference;

  return (
    <div className="relative w-72 h-72 mx-auto">
      <svg className="w-full h-full transform -rotate-90" viewBox="0 0 280 280">
        {/* Background circle */}
        <circle
          cx="140"
          cy="140"
          r={radius}
          fill="none"
          stroke="currentColor"
          className="text-gray-200"
          strokeWidth="8"
        />
        {/* Progress circle */}
        <circle
          cx="140"
          cy="140"
          r={radius}
          fill="none"
          className={config.ringClass}
          strokeWidth="8"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          style={{ transition: 'stroke-dashoffset 0.5s ease' }}
        />
      </svg>
      {/* Pulse ring when running */}
      {isRunning && (
        <div className={`absolute inset-0 rounded-full border-4 ${config.borderClass} timer-ring opacity-50`} />
      )}
    </div>
  );
}

function ModeSelector({ mode, setMode, isRunning }: { mode: TimerMode; setMode: (m: TimerMode) => void; isRunning: boolean }) {
  return (
    <div className="flex gap-2 justify-center mb-8">
      {(Object.keys(MODE_CONFIG) as TimerMode[]).map((m) => {
        const config = MODE_CONFIG[m];
        const Icon = config.icon;
        const isActive = mode === m;
        return (
          <button
            key={m}
            onClick={() => { if (!isRunning) setMode(m); }}
            disabled={isRunning}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl font-medium text-sm transition-all duration-200 ${
              isActive
                ? `${config.bgClass} ${config.textClass} shadow-sm scale-105`
                : 'bg-gray-100 text-gray-500 hover:bg-gray-200 disabled:opacity-50 disabled:cursor-not-allowed'
            }`}
          >
            <Icon size={16} />
            <span className="hidden sm:inline">{config.label}</span>
          </button>
        );
      })}
    </div>
  );
}

function SettingsPanel({ settings, onSave, onClose }: { settings: TimerSettings; onSave: (s: TimerSettings) => void; onClose: () => void }) {
  const [localSettings, setLocalSettings] = useState<TimerSettings>({ ...settings });

  const handleChange = (key: keyof TimerSettings, value: string) => {
    const num = parseInt(value) || 1;
    setLocalSettings(prev => ({ ...prev, [key]: Math.min(120, Math.max(1, num)) }));
  };

  const handleSave = () => {
    onSave(localSettings);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-2xl p-6 w-full max-w-sm" onClick={e => e.stopPropagation()}>
        <h2 className="text-xl font-bold text-gray-800 mb-6 flex items-center gap-2">
          <Settings size={20} />
          Настройки длительности
        </h2>
        
        <div className="space-y-4">
          {(Object.keys(MODE_CONFIG) as TimerMode[]).map((m) => {
            const config = MODE_CONFIG[m];
            return (
              <div key={m} className="flex items-center justify-between">
                <label className="text-sm font-medium text-gray-700">{config.label}</label>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min="1"
                    max="120"
                    value={localSettings[m]}
                    onChange={(e) => handleChange(m, e.target.value)}
                    className="w-20 px-3 py-2 border border-gray-300 rounded-lg text-center text-sm focus:outline-none focus:ring-2 focus:ring-offset-1 focus:ring-gray-400"
                  />
                  <span className="text-sm text-gray-500">мин</span>
                </div>
              </div>
            );
          })}
        </div>

        <div className="flex gap-3 mt-8">
          <button
            onClick={onClose}
            className="flex-1 px-4 py-2.5 border border-gray-300 text-gray-700 rounded-xl font-medium hover:bg-gray-50 transition-colors"
          >
            Отмена
          </button>
          <button
            onClick={handleSave}
            className="flex-1 px-4 py-2.5 bg-gray-900 text-white rounded-xl font-medium hover:bg-gray-800 transition-colors"
          >
            Сохранить
          </button>
        </div>
      </div>
    </div>
  );
}

function StatsPanel({ stats, onClose }: { stats: Stats; onClose: () => void }) {
  const todaySessions = getTodaySessions(stats);
  const totalMinutes = getTotalFocusMinutes(stats);
  const sessionCount = getTodaySessionCount(stats);
  const today = new Date().toLocaleDateString('ru-RU', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });

  return (
    <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-2xl p-6 w-full max-w-sm" onClick={e => e.stopPropagation()}>
        <h2 className="text-xl font-bold text-gray-800 mb-2 flex items-center gap-2">
          <BarChart3 size={20} />
          Статистика за сегодня
        </h2>
        <p className="text-sm text-gray-500 mb-6 capitalize">{today}</p>

        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className="bg-red-50 rounded-xl p-4 text-center">
            <div className="text-3xl font-bold text-red-600">{totalMinutes}</div>
            <div className="text-xs text-red-500 mt-1">минут фокуса</div>
          </div>
          <div className="bg-purple-50 rounded-xl p-4 text-center">
            <div className="text-3xl font-bold text-purple-600">{sessionCount}</div>
            <div className="text-xs text-purple-500 mt-1">сессий</div>
          </div>
        </div>

        {todaySessions.length > 0 ? (
          <div className="space-y-2 max-h-48 overflow-y-auto">
            <h3 className="text-sm font-semibold text-gray-700 mb-2">Сессии:</h3>
            {todaySessions.map((session, i) => (
              <div key={i} className="flex items-center justify-between bg-gray-50 rounded-lg px-3 py-2">
                <div className="flex items-center gap-2">
                  <CheckCircle2 size={14} className="text-green-500" />
                  <span className="text-sm text-gray-700">{session.duration} мин</span>
                </div>
                <span className="text-xs text-gray-400">
                  {new Date(session.completedAt).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-6">
            <Clock size={32} className="mx-auto text-gray-300 mb-2" />
            <p className="text-sm text-gray-400">Пока нет завершённых сессий</p>
          </div>
        )}

        <button
          onClick={onClose}
          className="w-full mt-6 px-4 py-2.5 bg-gray-900 text-white rounded-xl font-medium hover:bg-gray-800 transition-colors"
        >
          Закрыть
        </button>
      </div>
    </div>
  );
}

// Electron API type
declare global {
  interface Window {
    electronAPI?: {
      onTimerAction: (callback: (action: string) => void) => void;
      removeTimerListeners: () => void;
    };
  }
}

// Main App
export default function App() {
  const [mode, setMode] = useState<TimerMode>('focus');
  const [settings, setSettings] = useState<TimerSettings>(loadSettings);
  const [stats, setStats] = useState<Stats>(loadStats);
  const [timeLeft, setTimeLeft] = useState(settings.focus * 60);
  const [isRunning, setIsRunning] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showStats, setShowStats] = useState(false);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const startTimeRef = useRef<number>(0);
  const elapsedBeforePauseRef = useRef<number>(0);

  // Electron integration — handle actions from tray menu
  useEffect(() => {
    if (window.electronAPI) {
      window.electronAPI.onTimerAction((action: string) => {
        switch (action) {
          case 'start':
            setIsRunning(true);
            break;
          case 'pause':
            setIsRunning(false);
            break;
          case 'reset':
            handleReset();
            break;
        }
      });
      return () => {
        window.electronAPI?.removeTimerListeners();
      };
    }
  }, []);

  const totalTime = settings[mode] * 60;
  const progress = ((totalTime - timeLeft) / totalTime) * 100;
  const config = MODE_CONFIG[mode];

  // Timer logic
  useEffect(() => {
    if (isRunning) {
      startTimeRef.current = Date.now();
      intervalRef.current = setInterval(() => {
        setTimeLeft(prev => {
          if (prev <= 1) {
            // Timer completed
            clearInterval(intervalRef.current!);
            setIsRunning(false);
            
            if (mode === 'focus') {
              // Record completed focus session
              const session: FocusSession = {
                date: getToday(),
                duration: settings.focus,
                completedAt: new Date().toISOString(),
              };
              setStats(prevStats => {
                const newStats = { ...prevStats, sessions: [...prevStats.sessions, session] };
                saveStats(newStats);
                return newStats;
              });
            }
            
            // Play notification sound
            try {
              const audioCtx = new AudioContext();
              const oscillator = audioCtx.createOscillator();
              const gainNode = audioCtx.createGain();
              oscillator.connect(gainNode);
              gainNode.connect(audioCtx.destination);
              oscillator.frequency.value = 800;
              oscillator.type = 'sine';
              gainNode.gain.value = 0.3;
              oscillator.start();
              setTimeout(() => {
                oscillator.stop();
                audioCtx.close();
              }, 300);
            } catch (e) {
              // Audio not available
            }
            
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isRunning, mode, settings.focus]);

  // Update title with timer
  useEffect(() => {
    document.title = isRunning 
      ? `${formatTime(timeLeft)} — ${config.label}` 
      : 'Pomodoro Focus Timer';
  }, [timeLeft, isRunning, config.label]);

  const handleStart = () => {
    setIsRunning(true);
  };

  const handlePause = () => {
    setIsRunning(false);
  };

  const handleReset = () => {
    setIsRunning(false);
    setTimeLeft(settings[mode] * 60);
  };

  const handleModeChange = (newMode: TimerMode) => {
    setMode(newMode);
    setIsRunning(false);
    setTimeLeft(settings[newMode] * 60);
  };

  const handleSettingsSave = (newSettings: TimerSettings) => {
    setSettings(newSettings);
    saveSettings(newSettings);
    if (!isRunning) {
      setTimeLeft(newSettings[mode] * 60);
    }
  };

  const todayMinutes = getTotalFocusMinutes(stats);
  const todayCount = getTodaySessionCount(stats);

  return (
    <div className={`min-h-screen ${config.bgClass} transition-colors duration-500`}>
      <div className="max-w-md mx-auto px-4 py-8 min-h-screen flex flex-col">
        {/* Header */}
        <header className="flex items-center justify-between mb-8">
          <h1 className="text-xl font-bold text-gray-800 flex items-center gap-2">
            <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${config.gradientClass} flex items-center justify-center`}>
              <Timer size={16} className="text-white" />
            </div>
            Pomodoro
          </h1>
          <div className="flex gap-2">
            <button
              onClick={() => setShowStats(true)}
              className="p-2.5 rounded-xl bg-white shadow-sm hover:shadow-md transition-all text-gray-600 hover:text-gray-800"
              title="Статистика"
            >
              <BarChart3 size={18} />
            </button>
            <button
              onClick={() => setShowSettings(true)}
              className="p-2.5 rounded-xl bg-white shadow-sm hover:shadow-md transition-all text-gray-600 hover:text-gray-800"
              title="Настройки"
            >
              <Settings size={18} />
            </button>
          </div>
        </header>

        {/* Today's quick stats */}
        <div className="flex justify-center gap-6 mb-6">
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <CheckCircle2 size={14} className="text-green-500" />
            <span><strong>{todayCount}</strong> сессий</span>
          </div>
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <Clock size={14} className="text-red-500" />
            <span><strong>{todayMinutes}</strong> мин фокуса</span>
          </div>
        </div>

        {/* Mode Selector */}
        <ModeSelector mode={mode} setMode={handleModeChange} isRunning={isRunning} />

        {/* Timer Display */}
        <div className="relative flex-1 flex items-center justify-center">
          <div className="relative">
            <CircularProgress progress={progress} mode={mode} isRunning={isRunning} />
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-6xl font-mono font-bold text-gray-800 tracking-tight">
                {formatTime(timeLeft)}
              </span>
              <span className={`text-sm font-medium mt-2 ${config.textClass}`}>
                {config.label}
              </span>
              {isRunning && (
                <span className="text-xs text-gray-400 mt-1 animate-pulse">
                  Работает...
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center justify-center gap-4 pb-8">
          <button
            onClick={handleReset}
            className="p-4 rounded-full bg-white shadow-md hover:shadow-lg transition-all text-gray-600 hover:text-gray-800 active:scale-95"
            title="Сброс"
          >
            <RotateCcw size={22} />
          </button>
          
          <button
            onClick={isRunning ? handlePause : handleStart}
            className={`p-6 rounded-full shadow-lg hover:shadow-xl transition-all text-white active:scale-95 ${config.btnClass}`}
            title={isRunning ? 'Пауза' : 'Запуск'}
          >
            {isRunning ? <Pause size={32} /> : <Play size={32} className="ml-1" />}
          </button>

          <div className="p-4 rounded-full bg-white shadow-md text-gray-400">
            <div className="w-[22px] h-[22px]" />
          </div>
        </div>

        {/* Footer hint */}
        <p className="text-center text-xs text-gray-400 pb-4">
          {timeLeft === 0 && mode === 'focus' ? '🎉 Сессия завершена! Отличный перерыв заслужен.' : 
           timeLeft === 0 ? '⏰ Перерыв окончен. Пора возвращаться к работе!' :
           isRunning ? '⏳ Сосредоточьтесь на задаче...' : '👇 Нажмите большую кнопку ▶ ниже для запуска'}
        </p>

        {/* First-time hint */}
        {!isRunning && timeLeft === totalTime && !localStorage.getItem('pomodoro-hint-shown') && (
          <div className="fixed bottom-6 left-1/2 -translate-x-1/2 bg-white rounded-2xl shadow-xl p-4 max-w-xs text-center animate-bounce z-40">
            <p className="text-sm text-gray-700 font-medium mb-1">Добро пожаловать!</p>
            <p className="text-xs text-gray-500 mb-3">Выберите режим выше и нажмите ▶ чтобы начать</p>
            <button
              onClick={() => localStorage.setItem('pomodoro-hint-shown', 'true')}
              className="text-xs text-gray-400 hover:text-gray-600 underline"
            >
              Понятно, скрыть
            </button>
          </div>
        )}
      </div>

      {/* Modals */}
      {showSettings && (
        <SettingsPanel
          settings={settings}
          onSave={handleSettingsSave}
          onClose={() => setShowSettings(false)}
        />
      )}
      {showStats && (
        <StatsPanel
          stats={stats}
          onClose={() => setShowStats(false)}
        />
      )}
    </div>
  );
}
