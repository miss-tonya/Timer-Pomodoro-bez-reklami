@echo off
title Pomodoro Timer - Start
echo.
echo ==========================================
echo   Starting Pomodoro Timer
echo ==========================================
echo.

:: Step 0 - Find Node.js
echo [Step 0] Looking for Node.js...
where node >nul 2>nul
if %errorlevel% equ 0 (
    echo   Found Node.js in PATH
    call node --version
    goto :node_ok
)

if exist "C:\Program Files\nodejs\node.exe" (
    set "PATH=C:\Program Files\nodejs;%PATH%"
    echo   Found Node.js in C:\Program Files\nodejs
    goto :node_ok
)

echo.
echo   [ERROR] Node.js not found!
echo.
echo   Please RESTART your computer after installing Node.js.
echo.
pause
exit /b

:node_ok
echo.

:: Step 1 - Install dependencies
echo [Step 1] Checking dependencies...
if not exist "node_modules" (
    echo   Installing (first run, may take 2-3 minutes)...
    call npm install
    if %errorlevel% neq 0 (
        echo.
        echo   [ERROR] npm install failed!
        pause
        exit /b
    )
)
echo   OK
echo.

:: Step 2 - Build
echo [Step 2] Building app...
call npm run build
if %errorlevel% neq 0 (
    echo.
    echo   [ERROR] Build failed!
    pause
    exit /b
)
echo   OK
echo.

:: Step 3 - Check files
echo [Step 3] Checking files...
if not exist "dist\index.html" (
    echo   [ERROR] dist\index.html not found!
    pause
    exit /b
)
if not exist "electron\main.cjs" (
    echo   [ERROR] electron\main.cjs not found!
    pause
    exit /b
)
echo   OK
echo.

:: Step 4 - Run
echo [Step 4] Starting Pomodoro Timer...
echo   (Window will open in a few seconds)
echo.
call npx electron electron\main.cjs

echo.
echo ==========================================
echo   App closed.
echo ==========================================
pause
