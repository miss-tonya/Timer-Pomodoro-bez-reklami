# Pomodoro Timer - Start (PowerShell)
# Right-click this file -> "Run with PowerShell"

Write-Host ""
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "  Pomodoro Timer - Starting..." -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host ""

# Check Node.js
Write-Host "[1/4] Checking Node.js..." -ForegroundColor Yellow
try {
    $nodeVersion = & node --version 2>&1
    Write-Host "  Found: $nodeVersion" -ForegroundColor Green
} catch {
    Write-Host "  ERROR: Node.js not found!" -ForegroundColor Red
    Write-Host "  Please restart your computer after installing Node.js." -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit
}

# Install dependencies
Write-Host ""
Write-Host "[2/4] Checking dependencies..." -ForegroundColor Yellow
if (-not (Test-Path "node_modules")) {
    Write-Host "  Installing (first run)..." -ForegroundColor Yellow
    npm install
    if ($LASTEXITCODE -ne 0) {
        Write-Host "  ERROR: npm install failed!" -ForegroundColor Red
        Read-Host "Press Enter to exit"
        exit
    }
}
Write-Host "  OK" -ForegroundColor Green

# Build
Write-Host ""
Write-Host "[3/4] Building app..." -ForegroundColor Yellow
npm run build
if ($LASTEXITCODE -ne 0) {
    Write-Host "  ERROR: Build failed!" -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit
}
Write-Host "  OK" -ForegroundColor Green

# Run
Write-Host ""
Write-Host "[4/4] Starting Pomodoro Timer..." -ForegroundColor Yellow
Write-Host "  (App window will open shortly)" -ForegroundColor Gray
Write-Host ""
npx electron electron/main.cjs

Write-Host ""
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "  App closed." -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan
Read-Host "Press Enter to exit"
