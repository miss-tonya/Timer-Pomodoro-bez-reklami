@echo off
title Pomodoro Timer - Debug
echo.
echo ==========================================
echo   DEBUG - Pomodoro Timer
echo ==========================================
echo.

echo === System Info ===
echo.

echo [1] Node.js:
where node 2>nul
if %errorlevel% equ 0 (
    call node --version
) else (
    echo   NOT FOUND
)
echo.

echo [2] npm:
where npm 2>nul
if %errorlevel% equ 0 (
    call npm --version
) else (
    echo   NOT FOUND
)
echo.

echo [3] npx:
where npx 2>nul
if %errorlevel% equ 0 (
    echo   OK
) else (
    echo   NOT FOUND
)
echo.

echo [4] Current folder:
cd
echo.

echo [5] Files check:
if exist "package.json" (echo   package.json - OK) else (echo   package.json - MISSING!)
if exist "dist\index.html" (echo   dist\index.html - OK) else (echo   dist\index.html - MISSING!)
if exist "electron\main.cjs" (echo   electron\main.cjs - OK) else (echo   electron\main.cjs - MISSING!)
if exist "electron\preload.cjs" (echo   electron\preload.cjs - OK) else (echo   electron\preload.cjs - MISSING!)
if exist "node_modules" (echo   node_modules - OK) else (echo   node_modules - MISSING!)
echo.

echo [6] Electron version:
if exist "node_modules\electron" (
    call npx electron --version
) else (
    echo   NOT INSTALLED
)
echo.

echo ==========================================
echo   If something is MISSING:
echo.
echo   - node_modules MISSING: run start.bat
echo   - dist MISSING: run start.bat
echo   - node NOT FOUND: restart computer
echo ==========================================
echo.
echo Press any key to close...
pause >nul
