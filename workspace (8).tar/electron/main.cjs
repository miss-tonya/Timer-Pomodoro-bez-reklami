const { app, BrowserWindow, Tray, Menu, nativeImage } = require('electron');
const path = require('path');

let mainWindow;
let tray;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 420,
    height: 720,
    minWidth: 380,
    minHeight: 600,
    resizable: true,
    title: 'Pomodoro Focus Timer',
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      nodeIntegration: false,
      contextIsolation: true,
    },
    backgroundColor: '#fef2f2',
    show: false,
    autoHideMenuBar: true,
  });

  // Load the built Vite app
  const indexPath = path.join(__dirname, '..', 'dist', 'index.html');
  mainWindow.loadFile(indexPath);

  // Show window when ready
  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
    mainWindow.focus();
  });

  // Minimize to tray on close
  mainWindow.on('close', (event) => {
    if (!app.isQuitting) {
      event.preventDefault();
      mainWindow.hide();
    }
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

function createTray() {
  // Create a simple colored icon programmatically
  const iconSize = 16;
  const canvas = Buffer.alloc(iconSize * iconSize * 4);
  
  for (let y = 0; y < iconSize; y++) {
    for (let x = 0; x < iconSize; x++) {
      const idx = (y * iconSize + x) * 4;
      const centerX = iconSize / 2;
      const centerY = iconSize / 2;
      const dist = Math.sqrt((x - centerX) ** 2 + (y - centerY) ** 2);
      
      if (dist < iconSize / 2 - 1) {
        canvas[idx] = 239;     // R
        canvas[idx + 1] = 68;  // G
        canvas[idx + 2] = 68;  // B
        canvas[idx + 3] = 255; // A
      } else {
        canvas[idx + 3] = 0;
      }
    }
  }
  
  const icon = nativeImage.createFromBuffer(canvas, { width: iconSize, height: iconSize });
  
  try {
    tray = new Tray(icon);
  } catch (e) {
    console.log('Tray not supported on this system');
    return;
  }

  const contextMenu = Menu.buildFromTemplate([
    {
      label: 'Show Timer',
      click: () => {
        mainWindow.show();
        mainWindow.focus();
      }
    },
    { type: 'separator' },
    {
      label: 'Start',
      click: () => {
        mainWindow.show();
        mainWindow.webContents.send('timer-action', 'start');
      }
    },
    {
      label: 'Pause',
      click: () => {
        mainWindow.webContents.send('timer-action', 'pause');
      }
    },
    {
      label: 'Reset',
      click: () => {
        mainWindow.webContents.send('timer-action', 'reset');
      }
    },
    { type: 'separator' },
    {
      label: 'Quit',
      click: () => {
        app.isQuitting = true;
        app.quit();
      }
    }
  ]);

  tray.setToolTip('Pomodoro Focus Timer');
  tray.setContextMenu(contextMenu);
  
  tray.on('click', () => {
    if (mainWindow.isVisible()) {
      mainWindow.hide();
    } else {
      mainWindow.show();
      mainWindow.focus();
    }
  });
}

// Single instance lock
const gotTheLock = app.requestSingleInstanceLock();

if (!gotTheLock) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.show();
      mainWindow.focus();
    }
  });

  app.whenReady().then(() => {
    createWindow();
    createTray();

    app.on('activate', () => {
      if (BrowserWindow.getAllWindows().length === 0) {
        createWindow();
      }
    });
  });
}

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('before-quit', () => {
  app.isQuitting = true;
});
