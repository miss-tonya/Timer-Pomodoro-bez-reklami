const { contextBridge, ipcRenderer } = require('electron');

// Secure bridge between Electron and React
contextBridge.exposeInMainWorld('electronAPI', {
  onTimerAction: (callback) => {
    ipcRenderer.on('timer-action', (event, action) => callback(action));
  },
  removeTimerListeners: () => {
    ipcRenderer.removeAllListeners('timer-action');
  }
});
