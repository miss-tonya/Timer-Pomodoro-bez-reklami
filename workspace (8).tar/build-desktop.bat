@echo off
title Pomodoro Desktop - Build
echo.
echo ==========================================
echo   Pomodoro Focus Timer - Build .exe
echo ==========================================
echo.

:: Try to find Node.js
where node >nul 2>nul
if %errorlevel% equ 0 goto :found_node

if exist "C:\Program Files\nodejs\node.exe" (
    set "PATH=C:\Program Files\nodejs;%PATH%"
    goto :found_node
)

echo [ERROR] Node.js not found!
echo.
echo Please RESTART your computer after installing Node.js.
echo.
pause
exit /b 1

:found_node
echo Found Node.js:
call node --version
echo.

echo [1/3] Installing dependencies...
call npm install
if %errorlevel% neq 0 (
    echo [ERROR] Failed to install dependencies
    pause
    exit /b 1
)

echo.
echo [2/3] Building web app...
call npm run build
if %errorlevel% neq 0 (
    echo [ERROR] Failed to build app
    pause
    exit /b 1
)

echo.
echo [3/3] Creating desktop app...
call npx electron-builder --win --x64
if %errorlevel% neq 0 (
    echo [ERROR] Failed to create .exe
    pause
    exit /b 1
)

echo.
echo ==========================================
echo   DONE!
echo.
echo   The .exe file is in the "release" folder
echo ==========================================
echo.
pause
